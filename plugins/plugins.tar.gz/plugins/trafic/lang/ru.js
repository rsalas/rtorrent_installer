﻿/*
 * PLUGIN TRAFFIC
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.traf 		= "Трафик";
 theUILang.perDay		= "За сутки";
 theUILang.perMonth		= "За месяц";
 theUILang.perYear		= "За год";
 theUILang.allTrackers		= "Все трекеры";
 theUILang.ClearButton		= "Очистить";
 theUILang.ClearQuest		= "Вы действительно хотите очистить статистику для выбранных трекеров?";
 theUILang.selectedTorrent	= "Выбранные торренты";
 theUILang.ratioDay		= "Ратио/день";
 theUILang.ratioWeek		= "Ратио/неделя";
 theUILang.ratioMonth		= "Ратио/месяц";
