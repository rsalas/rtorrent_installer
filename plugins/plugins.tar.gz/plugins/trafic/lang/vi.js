﻿/*
 * PLUGIN TRAFFIC
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.traf 		= "Lưu lượng";
 theUILang.perDay		= "Trong ngày";
 theUILang.perMonth		= "Trong tháng";
 theUILang.perYear		= "Trong năm";
 theUILang.allTrackers		= "Tất cả máy theo dõi";
 theUILang.ClearButton		= "Xóa";
 theUILang.ClearQuest		= "Bạn có thực sự muốn xóa thống kê lưu lượng của các máy theo dõi đã chọn?";
 theUILang.selectedTorrent	= "Torrent(s) đã chọn";
 theUILang.ratioDay		= "Tỉ lệ/ngày";
 theUILang.ratioWeek		= "Tỉ lệ/tuần";
 theUILang.ratioMonth		= "Tỉ lệ/tháng";
