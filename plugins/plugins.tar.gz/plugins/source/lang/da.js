﻿/*
 * PLUGIN SOURCE
 *
 * Danish language file.
 *
 * Author: 
 */

 theUILang.getSource		= "Get .torrent";
 theUILang.cantFindTorrent	= "Source torrent file for this download not found.";

thePlugins.get("source").langLoaded();