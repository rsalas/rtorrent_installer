﻿/*
 * PLUGIN LoginMGR
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.accLogin		= "登录";
 theUILang.accPassword		= "密码";
 theUILang.accAccounts		= "帐号";
 theUILang.accAuto		= "Autologin";
 theUILang.acAutoNone		= "None";
 theUILang.acAutoDay		= "Every day";
 theUILang.acAutoWeek		= "Every week";
 theUILang.acAutoMonth		= "Every month";

thePlugins.get("loginmgr").langLoaded();