# _noty2

What is _noty2?
===============

_noty2 is a drop-in replacement for the rutorrent plugin _noty. It
uses the Web Notifications API instead of the jQuery plugin noty.

Installation
============

Download this repository as a zip-file and drop it in your plugins
folder. It is not possible to have both _noty and _noty2 installed at
the same time.
