﻿/*
 * PLUGIN THEME
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.themeStandard	= "Standard";
 theUILang.theme		= "Thème";

thePlugins.get("theme").langLoaded();