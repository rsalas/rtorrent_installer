﻿/*
 * PLUGIN THEME
 *
 * Serbian language file.
 *
 * Author: 
 */

 theUILang.themeStandard	= "Standard";
 theUILang.theme		= "Theme";

thePlugins.get("theme").langLoaded();