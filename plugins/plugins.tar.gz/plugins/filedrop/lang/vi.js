﻿/*
 * PLUGIN FILEDROP
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.doesntSupportHTML5	= "Gói bổ sung filedrop: Trình duyệt của bạn không hỗ trợ tính năng tải lên của HTML5. Gói bổ sung không chạy.";
 theUILang.tooManyFiles 	= "Gói bổ sung filedrop: Quá nhiều tập tin. Số tập tin phải <= ";
 theUILang.fileTooLarge 	= "quá lớn. Vui lòng tải lên tối đa";

thePlugins.get("filedrop").langLoaded();