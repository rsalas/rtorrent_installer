﻿/*
 * PLUGIN FILEDROP
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.doesntSupportHTML5	= "Plugin filedrop: Su navegador no soporta subidas por HTML5. El Plugin fué deshabilitado.";
 theUILang.tooManyFiles 	= "Plugin filedrop: Demasiados archivos. Deben ser <= ";
 theUILang.fileTooLarge 	= "demasiado grande. Por favor suba los archivos a";

thePlugins.get("filedrop").langLoaded();