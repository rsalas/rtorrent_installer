﻿/*
 * PLUGIN FILEDROP
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.doesntSupportHTML5	= "Плагин filedrop: Ваш браузер не поддерживает HTML5 загрузку файлов. Плагин выгружен.";
 theUILang.tooManyFiles 	= "Плагин filedrop: Слишком много файлов. Должно быть <= ";
 theUILang.fileTooLarge 	= "слишком большой. Могут быть загружены файлы размером <=";

thePlugins.get("filedrop").langLoaded();