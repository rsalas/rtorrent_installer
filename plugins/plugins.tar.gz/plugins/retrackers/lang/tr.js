﻿/*
 * PLUGIN RETRACKERS
 *
 * Turkish language file.
 *
 * Author: 
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "Add Announces";
 theUILang.retrackersDel	= "Remove Announces";
 theUILang.dontAddToPrivate	= "Don't touch private torrents";
 theUILang.addToBegin		= "Add announces to the beginning of the trackers list";

thePlugins.get("retrackers").langLoaded();