#ifndef LOCK_NONE_H_INCLUDED
#define LOCK_NONE_H_INCLUDED

#include "lock.h"

lock *
xmlrpc_lock_create_none(void);

#endif
